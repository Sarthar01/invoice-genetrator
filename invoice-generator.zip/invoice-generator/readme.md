<h1>Step : 1 </h1>

```
Open app.js
```
<h1>Step : 2 </h1>

```
Run command Node app.js or Nodemon app.js
```
<h1>Step : 3 </h1>

```
Open browser and seaech locahost:300
```